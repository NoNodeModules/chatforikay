let socket = io.connect("http://localhost:4000");
const date = new Date();
const profile = [
  "https://www.w3schools.com/w3images/avatar2.png",
  "https://www.w3schools.com/w3images/avatar4.png",
  "https://www.w3schools.com/w3images/avatar3.png",
  "https://www.w3schools.com/w3images/avatar5.png",
  "https://www.w3schools.com/w3images/avatar6.png"
];
const username = prompt("Enter a Username");

document.querySelector("body").innerHTML += `
<p>${username} joined the chat</p>
<sub id="new">${date.getHours() + ":" + date.getMinutes()}</sub>
<br>
`

document.getElementById("app").innerHTML = ` 
<div class="wrapper">
<div class="input-data">
<input type="text" id="text" placeholder="Type Comment" size="50">
</div>
</div>`;

document.querySelector("input").addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
        console.log("enter");
      socket.emit('chat', {
          message: document.getElementById("text").value,
          handle: username
      })
    }
  });

  socket.on('chat', (data) => {

    if (data.message !== "") {
        document.querySelector("body").innerHTML += `
     <img src="${profile[Math.floor(Math.random() * profile.length)]}" width="40px">
     <sub>${data.handle}</sub> 
     <sup>${date.getHours() + ":" + date.getMinutes()}</sup>
      <h3>${data.message}</h3>
      `;
      }
     document.getElementById("text").value = "";
      document.querySelector("input").addEventListener("keyup", (event) => {
        if (event.key === "Enter") {
            socket.emit('chat', {
                message: document.getElementById("text").value,
                handle: username
            })
        }
      });
  })

